<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$db="emomusic";
	$conn = mysqli_connect($servername, $username, $password,$db);
?>